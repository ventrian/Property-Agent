SurfTo v1.0.0.2
(c) 2007 Stephen Topilnycky * Top Cat Computing - All Rights Reserved
Questions/Comments: steve@topcatcomputing.com
=================================================================================


                        LICENSE AGREEMENT

NO WARRANTY.  ANY USE BY YOU OF THE SOFTWARE IS AT YOUR OWN RISK.  THE
SOFTWARE IS PROVIDED FOR USE "AS IS" WITHOUT WARRANTY OF ANY KIND.  TO
THE MAXIMUM EXTENT PERMITTED BY LAW, THE AUTHOR AND ITS SUPPLIERS
DISCLAIM ALL WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE. THE AUTHOR IS NOT OBLIGATED TO PROVIDE
ANY UPDATES TO THE SOFTWARE.

NO LIABILITY FOR CONSEQUENTIAL DAMAGES.  In no event shall The Author or
its suppliers be liable for any damages whatsoever (including, without
limitation, incidental, direct, indirect special and consequential damages,
damages for loss of business profits, business interruption, loss of
business information, or other pecuniary loss) arising out of the use or
inability to use this Authors product, even if The Author has been advised
of the possibility of such damages.  Because some states/countries do not
allow the exclusion or limitation of liability for consequential or
incidental damages, the above limitation may not apply to you.
You are free to use and modify this code to suite your own needs. 
Please notate the code with your changes if you are sharing with others.


Description:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


This SurfTo.aspx file is designed to work with Ventrian Systems Property
Agent.

The purpose of this file is to increment the hit counter each time a user
clicks a link and then redirect them to the desired page.

You can view a sample of the template in action at
http://www.topcatcomputing.com/links.aspx

ZIP File Contents:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

LINKS.ZIP         - Ventrian Systems Property Agent Template
SurfTo.ZIP        - Top Cat Computing SurfTo.aspx and SurfTo.DLL
Surfto_Source.ZIP - Complete source code to the SurfTo.
Css.Txt           - CSS Styles used in the template
Readme.txt        - This File

Installation Instructions:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Place the SurfTo.aspx in your DNN root folder.
Place the surfTo.DLL  in your DNN \BIN folder.
Copy the contents of the Css.txt to your portal Stylesheet or change
the styles in the template to that of your choosing.

Use the Property Agent Module to import the LINKS.ZIP template.

You will need to edit the listing template and change the email address for the
bad link report. The template code looks like this:

<a href="MailTo:webmaster@topcatcomputing.com?Subject=Top Cat 
Computing Site:Bad Link Report&Body=[CUSTOM:Title] [LINK]">Report Broken Link</a> 


The enclose template already links to the surfto.aspx file.  

The syntax used is:


/surfto.aspx?link=http://www.topcatcomputing.com/

In the template it will look like this:

<a href="/surfto.aspx?link=[CUSTOM:URL]" target="_blank">

Included in this archive is the complete source and project file if you wish to 
customize this for yourself.


Revision History:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
1.0.0.0   22 MAR 07 - Original Release
1.0.0.2   16 DEC 07 - Fixed General Exception error when a Web Crawler
                      would attempt to access a link that present in 
                      the database. Now it will send a 404-Page Not
                      Found response and display an error page.